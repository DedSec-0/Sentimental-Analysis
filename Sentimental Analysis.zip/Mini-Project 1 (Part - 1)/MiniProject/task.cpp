#include<iostream>
#include<fstream>
using namespace std;

int NameCount = 0;
char name[20] = { '\0' };
int NameLength = 0;

void ConvertWordToLowerCase(char name [])
{
	for (int x = 0; name[x] != '\0'; x++)
	{
		if (name[x] >= 65 && name[x] <= 90)
		{
			name[x] = name[x] + 32;
		}
	}
}

void ClearWord(char word[])
{
	for (int x = 0; x < 140; x++)
	{
		word[x] = '\0';
	}
}

void GetWordLength(char word[], int & WordLength)
{
	for (int i = 0; word[i] != '\0'; i++)
	{
		WordLength++;
	}
}

void earch(int & flag, char Word[], int WordLength)
{
	flag = 0;

	if (NameLength == WordLength)
	{
		for (int i = 0; Word[i] != '\0'; i++)
		{
			if (Word[i] != name[i])
			{
				flag = 1;
				break;
			}
		}
	}
	else
	{
		flag = 1;
	}
}

void check(int & found, char nature)
{
	char WordSearch[20] = { '\0' };
	int SearchWordLength = 0;
	int flag = 0;
	int TotalCount = 0;
	int Positive = 0;
	int Negative = 0;

	ofstream fout;
	fout.open("temp.txt", ios::out);
	ifstream fin;
	fin.open("data.txt", ios::in);
	while (fin >> WordSearch >> TotalCount >> Positive >> Negative)
	{
		if (fin.eof())
		{
			break;
		}

		flag = 0;
		SearchWordLength = 0;
		GetWordLength(WordSearch, SearchWordLength);
		search(flag, WordSearch, SearchWordLength);
		if (flag == 0) // milgya
		{
			TotalCount++;
			if (nature == 'p')
			{
				Positive++;
			}
			else if (nature == 'n')
			{
				Negative++;
			}
			fout << WordSearch << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
			found = 1;
		}
		else
		{
			fout << WordSearch << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
		}
	}
	if (found == 2)
	{
		found = 0;
	}
	fout.close();
	fin.close();
}

void write(char nature)
{
	char TempName[50] = { '\0' };
	int found = 2;
	int TotalCount = 0;
	int Positive = 0;
	int Negative = 0;

	if (NameCount == 0)
	{
		ofstream fout;
		fout.open("data.txt", ios::out);
		if (nature == 'p')
		{
			Positive++;
		}
		else if (nature == 'n')
		{
			Negative++;
		}
		fout << name << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;

		fout.close();
		NameCount++;
	}
	else
	{
		check(found,nature);
	}

	if (found == 1)
	{
		ifstream fin;
		ofstream fout;
		fout.open("data.txt", ios::out);
		fin.open("temp.txt", ios::in);
		while (1)
		{
			fin >> TempName >> TotalCount >> Positive >> Negative;
			if (fin.eof())
			{
				break;
			}
			else
			{
				fout << TempName << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
			}
		}
		fin.close();
		fout.close();
	}
	else if (found == 0)
	{
		if (nature == 'p')
		{
			Positive++;
		}
		else if (nature == 'n')
		{
			Negative++;
		}
		ofstream fout;
		fout.open("data.txt", ios::app);
		fout << name << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
		fout.close();
	}
}

void read()
{
	char word[140] = { '\0' };
	char StopWord[20] = { '\0' };
	char nature = { '\0' };
	int flag = 0;
	int j = 0;
	int i = 1;
	int WordLength = 0;
	int StopWordLength = 0;

	ifstream fin;
	fin.open("rawdata.txt", ios::in);
	while (1)
	{
		WordLength = 0;
		ClearWord(word);
		fin.getline(word, 140);
		GetWordLength(word, WordLength);

		if (fin.eof())
		{
			break;
		}
		cout << "Enter p for positive and n for negative for sentence " << i << ": ";
		cin >> nature;

		j = 0;
		while (j < WordLength)
		{
			flag = 0;
			ClearWord(name);
			while (word[j] != ' ' && word[j] != '\0' && word[j] != '.')
			{
				name[NameLength] = word[j];
				NameLength++;
				j++;
			}
			ConvertWordToLowerCase(name);
			ifstream fin2;
			fin2.open("stopwords.txt", ios::in);
			while (1)
			{
				StopWordLength = 0;
				fin2.getline(StopWord, 20);
				GetWordLength(StopWord, StopWordLength);
				if (fin2.eof())
				{
					break;
				}
				search(flag, StopWord, StopWordLength);
				if (flag == 0) //milgya
				{
					break;
				}
			}
			fin2.close();
			if (flag == 1)
			{
				write(nature);
			}
			j++;
		}
		i++;
	}
}

int main()
{
	read();
	return 0;
}