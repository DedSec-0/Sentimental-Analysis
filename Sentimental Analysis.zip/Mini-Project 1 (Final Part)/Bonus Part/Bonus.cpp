#include<iostream>
#include<fstream>
using namespace std;

int x = 0;
int NameCount = 0;
char name[20] = { '\0' };
int NameLength = 0;

void ConvertWordToLowerCase(char name[]);
void ClearWord(char word[]);
void GetWordLength(char word[], int & WordLength);
void Search(int & flag, char Word[], int WordLength);
void GetSentences();
void CheckForNonAlphabetic(char name[], int & check);
void CheckWord(int & found, int PositiveOrNegative);
void write(int PostiveOrNegative);

void main()
{
	GetSentences();
}

void CheckForNonAlphabetic(char name[], int & check)
{
	check = 0;

	for (int x = 0; name[x] != '\0'; x++)
	{
		if ((name[x] > 64 && name[x] < 91) || (name[x] > 96 && name[x] < 123))
		{
			check = 1;
		}
		else
		{
			check = 0;
			break;
		}
	}
}

void ConvertWordToLowerCase(char name[])
{
	for (int x = 0; name[x] != '\0'; x++)
	{
		if (name[x] >= 65 && name[x] <= 90)
		{
			name[x] = name[x] + 32;
		}
	}
}

void ClearWord(char word[])
{
	for (int x = 0; x < 140; x++)
	{
		word[x] = '\0';
	}
}

void GetWordLength(char word[], int & WordLength)
{
	for (int i = 0; word[i] != '\0'; i++)
	{
		WordLength++;
	}
}

void Search(int & flag, char Word[], int WordLength)
{
	flag = 0;

	if (NameLength == WordLength)
	{
		for (int i = 0; Word[i] != '\0'; i++)
		{
			if (Word[i] != name[i])
			{
				flag = 1;
				break;
			}
		}
	}
	else
	{
		flag = 1;
	}
}

void CheckWord(int & found, int PositiveOrNegative)
{
	char WordSearch[50] = { '\0' };
	int SearchWordLength = 0;
	int flag = 0;
	int TotalCount = 0;
	int Positive = 0;
	int Negative = 0;

	ofstream fout;
	fout.open("temp.txt", ios::out);
	ifstream fin;
	fin.open("MyDictionary.txt", ios::in);
	while (fin >> WordSearch >> TotalCount >> Positive >> Negative)
	{
		if (fin.eof())
		{
			break;
		}

		flag = 0;
		SearchWordLength = 0;
		GetWordLength(WordSearch, SearchWordLength);
		Search(flag, WordSearch, SearchWordLength);
		if (flag == 0)
		{
			TotalCount++;
			if (PositiveOrNegative == 1)
			{
				Positive++;
			}
			else if (PositiveOrNegative == 0)
			{
				Negative++;
			}
			fout << WordSearch << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
			found = 1;
		}
		else
		{
			fout << WordSearch << ' ' << TotalCount << ' ' << Positive << ' ' << Negative << endl;
		}
	}
	if (found == 2)
	{
		found = 0;
	}
	fout.close();
	fin.close();
}

void write(int PostiveOrNegative)
{
	char TempName[50] = { '\0' };
	int found = 2;
	int TotalCount = 0;
	int P = 0;
	int N = 0;

	if (NameCount == 0)
	{
		ofstream fout;
		fout.open("MyDictionary.txt", ios::out);
		if (PostiveOrNegative == 1)
		{
			P++;
		}
		else if (PostiveOrNegative == 0)
		{
			N++;
		}
		TotalCount++;
		fout << name << ' ' << TotalCount << ' ' << P << ' ' << N << endl;
		fout.close();
		NameCount++;
	}
	else
	{
		CheckWord(found, PostiveOrNegative);
	}
	if (found == 1)
	{
		ifstream fin;
		ofstream fout;
		fout.open("MyDictionary.txt", ios::out);
		fin.open("temp.txt", ios::in);
		while (1)
		{
			fin >> TempName >> TotalCount >> P >> N;
			if (fin.eof())
			{
				break;
			}
			else
			{
				fout << TempName << ' ' << TotalCount << ' ' << P << ' ' << N << endl;
			}
		}
		fin.close();
		fout.close();
	}
	else if (found == 0)
	{
		if (PostiveOrNegative == 1)
		{
			P++;
		}
		else if (PostiveOrNegative == 0)
		{
			N++;
		}
		ofstream fout;
		fout.open("MyDictionary.txt", ios::app);
		TotalCount++;
		fout << name << ' ' << TotalCount << ' ' << P << ' ' << N << endl;
		fout.close();
	}
}



void GetSentences()
{
	char word[170] = { '\0' };
	char StopWord[20] = { '\0' };
	int flag = 0;
	int j = 0;
	int check = 0;
	int WordLength = 0;
	int StopWordLength = 0;
	int PostiveOrNegative;

	ifstream fin;
	fin.open("rawdata.txt", ios::in);
	if (fin.is_open())
	{
		cout << "Yes" << endl;
	}
	while (1)
	{
		WordLength = 0;
		ClearWord(word);
		PostiveOrNegative = 0;
		while (1)
		{
			fin >> PostiveOrNegative;
			if (PostiveOrNegative == 0 || PostiveOrNegative == 1)
			{
				break;
			}
		}
		fin.getline(word, 170);
		cout << word << endl;
		GetWordLength(word, WordLength);

		if (fin.eof())
		{
			break;
		}

		j = 0;
		while (j < WordLength)
		{
			flag = 0;
			ClearWord(name);
			if (word[j] == ' ' || word[j] == ',')
			{
				j++;
			}
			while (word[j] != ' ' && word[j] != '\0' && word[j] != '.' && word[j] != ',')
			{
				name[NameLength] = word[j];
				NameLength++;
				j++;
			}
			CheckForNonAlphabetic(name, check);
			if (check == 1)
			{
				ConvertWordToLowerCase(name);

				ifstream fin2;
				fin2.open("stopwords.txt", ios::in);
				while (1)
				{
					StopWordLength = 0;
					fin2.getline(StopWord, 20);

					if (fin2.eof())
					{
						break;
					}

					GetWordLength(StopWord, StopWordLength);
					Search(flag, StopWord, StopWordLength);
					if (flag == 0)
					{
						break;
					}
				}
				fin2.close();
				if (flag == 1)
				{
					write(PostiveOrNegative);
				}
				j++;
			}
			else
			{
				j++;
			}
		}
	}
}