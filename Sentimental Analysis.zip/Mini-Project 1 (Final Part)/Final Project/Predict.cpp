#include<iostream>
#include<fstream>
using namespace std;

int x = 0;
int NameCount = 0;
char name[20] = { '\0' };
int NameLength = 0;

void ConvertWordToLowerCase();
void ClearWord();
void GetWordLength();
void Search();
void GetCounts();
void FileRead();
void UserRead();
void CheckForNonAlphabetic();
void GetNormalizedCount();
void Print();

void main()
{
	cout << "Enter 1 to write Sentences Manually or " << endl << "0 to read from file or: ";
	cin >> x;

	if (x == 0)
	{
		FileRead();
	}
	else
	{
		UserRead();
	}
}

void Print(char word [], double ComputePositive, double ComputeNegative, int Positive, int Negative)
{
	system("CLS");

	cout << "Sentence is: " << word << endl << endl;
	cout << "Without Normalization: " << endl << "Positve Count: " << Positive << endl << "Negtive count: " << Negative << endl << endl;
	cout << "********************" << endl;
	if (Positive > Negative)
	{
		cout << "* Text is positve *" << endl;
	}
	else
	{
		cout << "* Text is negative *" << endl;
	}
	cout << "********************" << endl << endl;

	cout << "With Normalization: " << endl << "Positve Count: " << ComputePositive << endl << "Negtive count: " << ComputeNegative << endl << endl;
	cout << "********************" << endl;
	if (ComputePositive > ComputeNegative)
	{
		cout << "* Text is positve *" << endl;
	}
	else
	{
		cout << "* Text is negative *" << endl;
	}
	cout << "********************" << endl << endl;
}

void CheckForNonAlphabetic(char name[], int & check)
{
	check = 0;

	for (int x = 0; name[x] != '\0'; x++)
	{
		if ((name[x] > 64 && name[x] < 91) || (name[x] > 96 && name[x] < 123))
		{
			check = 1;
		}
		else
		{
			check = 0;
			break;
		}
	}
}

void ConvertWordToLowerCase(char name[])
{
	for (int x = 0; name[x] != '\0'; x++)
	{
		if (name[x] >= 65 && name[x] <= 90)
		{
			name[x] = name[x] + 32;
		}
	}
}

void ClearWord(char word[])
{
	for (int x = 0; x < 140; x++)
	{
		word[x] = '\0';
	}
}

void GetWordLength(char word[], int & WordLength)
{
	for (int i = 0; word[i] != '\0'; i++)
	{
		WordLength++;
	}
}

void Search(int & flag, char Word[], int WordLength)
{
	flag = 0;

	if (NameLength == WordLength)
	{
		for (int i = 0; Word[i] != '\0'; i++)
		{
			if (Word[i] != name[i])
			{
				flag = 1;
				break;
			}
		}
	}
	else
	{
		flag = 1;
	}
}

void GetNormalizedCount(double & ComputePositive, double & ComputeNegative, float positive, float negative, int count)
{
	ComputePositive = ComputePositive + (positive / count);
	ComputeNegative = ComputeNegative + (negative / count);
}

void GetCounts(int & Positive, int & Negative, double & ComputePositive, double & ComputeNegative)
{
	int Found = 2;
	int count = 0;
	int Length = 0;
	float positive = 0;
	float negative = 0;
	char word1[50] = { '\0' };

	ifstream fin;
	fin.open("dictionary.txt", ios::in);
	while (fin >> word1 >> count >> positive >> negative)
	{
		if (fin.eof())
		{
			break;
		}
		Length = 0;
		GetWordLength(word1, Length);
		Search(Found, word1, Length);
		if (Found == 0)
		{
			Positive = Positive + positive;
			Negative = Negative + negative;
			GetNormalizedCount(ComputePositive, ComputeNegative, positive, negative, count);
			break;
		}
	}
	fin.close();
}

void FileRead()
{
	char word[170] = { '\0' };
	char StopWord[20] = { '\0' };
	char nature = { '\0' };
	int flag = 0;
	int j = 0;
	int i = 1;
	int check = 0;
	int WordLength = 0;
	int StopWordLength = 0;
	int Positive = 0;
	int Negative = 0;
	double ComputePositive = 0;
	double ComputeNegative = 0;

	ifstream fin;
	fin.open("rawdata.txt", ios::in);
	while (1)
	{
		WordLength = 0;
		ClearWord(word);
		fin.getline(word, 170);
		GetWordLength(word, WordLength);

		if (fin.eof())
		{
			break;
		}
		cout << "Enter prediction for sentence " << i << endl << "p for positive and n for negative or q to quit: ";
		cin >> nature;
		if (nature == 'q')
		{
			break;
		}


		j = 0;
		while (j < WordLength)
		{
			flag = 0;
			ClearWord(name);
			if (word[j] == ' ' || word[j] == ',')
			{
				j++;
			}
			while (word[j] != ' ' && word[j] != '\0' && word[j] != '.' && word[j] != ',')
			{
				name[NameLength] = word[j];
				NameLength++;
				j++;
			}
			CheckForNonAlphabetic(name, check);
			if (check == 1)
			{
				ConvertWordToLowerCase(name);

				ifstream fin2;
				fin2.open("stopwords.txt", ios::in);
				while (1)
				{
					StopWordLength = 0;
					fin2.getline(StopWord, 20);

					if (fin2.eof())
					{
						break;
					}

					GetWordLength(StopWord, StopWordLength);
					Search(flag, StopWord, StopWordLength);
					if (flag == 0)
					{
						break;
					}
				}
				fin2.close();
				if (flag == 1)
				{
					GetCounts(Positive, Negative, ComputePositive, ComputeNegative);
				}
				j++;
			}
			else
			{
				j++;
			}
		}
		Print(word, ComputePositive, ComputeNegative, Positive, Negative);

		Positive = 0;
		Negative = 0;
		ComputePositive = 0;
		ComputeNegative = 0;
		i++;
	}
}

void UserRead()
{
	char word[170] = { '\0' };
	char StopWord[20] = { '\0' };
	char nature = { '\0' };
	int flag = 0;
	int j = 0;
	int i = 1;
	int check = 0;
	int WordLength = 0;
	int StopWordLength = 0;
	int Positive = 0;
	int Negative = 0;
	double ComputePositive = 0;
	double ComputeNegative = 0;

	while (1)
	{
		WordLength = 0;
		ClearWord(word);
		cin.ignore();
		cout << "Enter the sentence " << i << " or q to quit: ";
		cin.getline(word, 170);
		if (word[0] == 'q')
		{
			break;
		}
		GetWordLength(word, WordLength);
		cout << "Enter prediction for sentence " << i << endl << "p for positive and n for negative: ";
		cin >> nature;

		j = 0;
		while (j < WordLength)
		{
			flag = 0;
			ClearWord(name);
			if (word[j] == ' ' || word[j] == ',')
			{
				j++;
			}
			while (word[j] != ' ' && word[j] != '\0' && word[j] != '.' && word[j] != ',')
			{
				name[NameLength] = word[j];
				NameLength++;
				j++;
			}
			CheckForNonAlphabetic(name, check);
			if (check == 1)
			{
				ConvertWordToLowerCase(name);

				ifstream fin2;
				fin2.open("stopwords.txt", ios::in);
				while (1)
				{
					StopWordLength = 0;
					fin2.getline(StopWord, 20);

					if (fin2.eof())
					{
						break;
					}

					GetWordLength(StopWord, StopWordLength);
					Search(flag, StopWord, StopWordLength);
					if (flag == 0)
					{
						break;
					}
				}
				fin2.close();
				if (flag == 1)
				{
					GetCounts(Positive, Negative, ComputePositive, ComputeNegative);
				}
				j++;
			}
			else
			{
				j++;
			}
		}
		i++;
		Print(word, ComputePositive, ComputeNegative, Positive, Negative);

		Positive = 0;
		Negative = 0;
		ComputePositive = 0;
		ComputeNegative = 0;

	}
}